from util import entropy, information_gain, partition_classes
import numpy as np 
import ast

class DecisionTree(object):
    def __init__(self):
        # Initializing the tree as an empty dictionary or list, as preferred
        #self.tree = []
        self.tree = {}
        # pass

    def calcSplitValue(self, X):
        # For numeric attributes, choose the average as split_value
        sumOfAttribute = [0.0] * len(X[0])
        for i in range(len(X[0])):
            for r in X:
                if not isinstance(r[i], (int, float, complex)):
                    break
                sumOfAttribute[i] += r[i]
        splitValueList = [sumAttribute / len(X) for sumAttribute in sumOfAttribute]

        # For categorical attributes, choose the majority value as split_value
        for i in range(len(X[0])):
            freqDict = {}
            maxFreq = 0
            for r in X:
                if isinstance(r[i], (int, float, complex)):
                    break
                if r[i] not in freqDict.keys():
                    freqDict[r[i]] = 1
                else:
                    freqDict[r[i]] += 1
            if len(freqDict) > 0:
                mKey = None
                for k,v in freqDict:
                    if v > maxFreq:
                        maxFreq = v
                        mKey = k
                splitValueList[i] = mKey
        return splitValueList


    def learn(self, X, y):
        # TODO: Train the decision tree (self.tree) using the the sample X and labels y
        # You will have to make use of the functions in utils.py to train the tree
        
        # One possible way of implementing the tree:
        #    Each node in self.tree could be in the form of a dictionary:
        #       https://docs.python.org/2/library/stdtypes.html#mapping-types-dict
        #    For example, a non-leaf node with two children can have a 'left' key and  a 
        #    'right' key. You can add more keys which might help in classification
        #    (eg. split attribute and split value)
        # pass

        # – If all the datapoints in X have the same class value y, Return a leaf node that predicts y as output
        if (len(set(y)) == 1):
            self.tree['label'] = y[0]
            return

        # – If all the datapoints in X have the same attribute value (x1,..,xM), Return a leaf node that predicts the majority of the class values in Y as output
        # setX = set()
        # for i in range(len(X[0])):
        #     for j in X:
        #         setX.add(X[i][j])
        # if (len(setX) == 1):
            

        # Initialize default value
        max_IG = -1 
        split_attribute = -1 
        split_val = -1

        # use mean value or most frequent value as split_val
        splitValueList = self.calcSplitValue(X)
        for j in range(len(X[0])):
            mySplitValue = splitValueList[j]
            x1, x2, y1, y2 = partition_classes(X, y, j, mySplitValue)
            current_y = [y1, y2]
            myIG = information_gain(y, current_y)
            if myIG > max_IG:
                max_IG = myIG
                split_attribute = j
                split_val = mySplitValue
                maxX1 = x1
                maxX2 = x2
                maxY1 = y1
                maxY2 = y2

        self.tree['left'] = DecisionTree()
        self.tree['right'] = DecisionTree()
        self.tree['attribute'] = split_attribute
        self.tree['value'] = split_val
        self.tree['left'].learn(maxX1, maxY1)
        self.tree['right'].learn(maxX2, maxY2)

    def classify(self, record):
        # TODO: classify the record using self.tree and return the predicted label
        # pass
        root = self.tree

        while 'left' in root:
            split_attribute = root['attribute']
            split_val = root['value']

            # If split is on numeric value
            if isinstance(record[split_attribute], (int, float, complex)):
                if record[split_attribute] <= split_val:
                    root = root['left'].tree
                else:
                    root = root['right'].tree
            else:
                if record[split_attribute] == split_val:
                    root = root['left'].tree
                else:
                    root = root['right'].tree
        return root['label']





