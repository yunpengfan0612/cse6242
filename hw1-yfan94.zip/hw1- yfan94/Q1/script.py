# coding: utf-8
import http.client
import json
import time
import timeit
import sys
import collections
from pygexf.gexf import *


#
# implement your data retrieval code here
#
start_time = time.time()
###################
####   Q1.1 a   ###
###################
myKey = 'key ' + sys.argv[1]
resSet = []
setNum = []
setPgSize = 300
partPgSize = 10000
minParts = 1166
# minParts = 4500
url = 'rebrickable.com'

urlGetSet = '/api/v3/lego/sets/?page_size=' + str(setPgSize) + '&min_parts=' + str(minParts) + '&ordering=-num_parts'
header = {'Accept': 'application/json',
		  'Authorization': myKey
		}

conn = http.client.HTTPSConnection(url)

conn.request("GET", urlGetSet, headers = header)
cResSet = conn.getresponse()
dataSet = json.loads(cResSet.read())
resultsSet = dataSet['results']
for r in resultsSet:
	myDict = {'set_num': r['set_num'], 'set_name': r['name']}
	resSet.append(myDict)
	setNum.append(r['set_num'])


###################
####   Q1.1 b   ###
###################
counter = 0
for s in resSet:
	urlGetPart = '/api/v3/lego/sets/' + str(s['set_num']) + '/parts/?page_size=' + str(partPgSize)
	conn.request("GET", urlGetPart, headers = header)
	cResPart = conn.getresponse()
	dataPart = json.loads(cResPart.read())
	resultsPart = dataPart['results']
	resPart = []
	for p in resultsPart:
		myDict = {'part_num': p['part']['part_num'], 'part_color': p['color']['rgb'], 'part_name': p['part']['name'], 'part_quantity': p['quantity']}
		myDict['part_id'] = str(myDict['part_num']) + '_' + str(myDict['part_color'])
		resPart.append(myDict)
	resPart = sorted(resPart, key = lambda i: i['part_quantity'],reverse=True)
	if (len(resPart) > 20):
		resPart = resPart[:20]
	s['part'] = resPart
	counter += 1
	print(counter)
	print("--- %s seconds ---" % (time.time() - start_time))

print("--- %s seconds ---" % (time.time() - start_time))

# complete auto grader functions for Q1.1.b,d
def min_parts():
	"""
	Returns an integer value
	"""
	# you must replace this with your own value

	return minParts

def lego_sets():
	"""
	return a list of lego sets.
	this may be a list of any type of values
	but each value should represent one set

	e.g.,
	biggest_lego_sets = lego_sets()
	print(len(biggest_lego_sets))
	> 280
	e.g., len(my_sets)
	"""
	# you must replace this line and return your own list
	return resSet

###################
####  Q1.1 c,d  ###
###################

def gexf_graph():
	"""
	return the completed Gexf graph object
	"""
	# you must replace these lines and supply your own graph
	# my_gexf = Gexf("author", "title")
	# gexf.addGraph("undirected", "static", "I'm an empty graph")

	gexf = Gexf("Yunpeng Fan", "My First Gexf")
	graph = gexf.addGraph("undirected", "static", "Rebrickable Lego Set and Part Graph")
	setAttrID = graph.addNodeAttribute(title = 'Type', type = 'string')

	for s in resSet:
		mySetNode = graph.addNode(id = s['set_num'], label = s['set_name'], r = '0', g = '0', b = '0')
		mySetNode.addAttribute(id = setAttrID, value = 'set')
		for p in s['part']:
			hexColor = p['part_color'].lstrip('#')
			hcLen = len(hexColor)
			myRGB = tuple(int(hexColor[i:i+hcLen//3], 16) for i in range(0, hcLen, hcLen//3))
			myPartNode = graph.addNode(id = p['part_id'], label = p['part_name'], r = str(myRGB[0]), g = str(myRGB[1]), b = str(myRGB[2]))
			myPartNode.addAttribute(id = setAttrID, value = 'part')
			edgeID = s['set_num'] + '_' + p['part_id']
			graph.addEdge(id = edgeID, source = s['set_num'], target = p['part_id'], weight = p['part_quantity'])

	output_file=open("bricks_graph.gexf","wb")
	gexf.write(output_file)
	output_file.close()
	return gexf.graphs[0]


# Generate graph output
print("Generate Graph")
gexf_graph()
print("--- %s seconds ---" % (time.time() - start_time))

# complete auto-grader functions for Q1.2.d


def avg_node_degree():
	"""
	hardcode and return the average node degree
	(run the function called “Average Degree”) within Gephi
	"""
	# you must replace this value with the avg node degree
	return 5.354

def graph_diameter():
	"""
	hardcode and return the diameter of the graph
	(run the function called “Network Diameter”) within Gephi
	"""
	# you must replace this value with the graph diameter
	return 8

def avg_path_length():
	"""
	hardcode and return the average path length
	(run the function called “Avg. Path Length”) within Gephi
	:return:
	"""
	# you must replace this value with the avg path length
	return 4.428