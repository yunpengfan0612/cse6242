function myWeight(d) {
	d.weight = path.filter(function(l) {
		return l.source.index == d.index || l.target.index == d.index;
	}).size();
	return d.weight;
};


// add the curvy lines
function tick() {
    path.attr("d", function(d) {
        var dx = d.target.x - d.source.x,
            dy = d.target.y - d.source.y,
            dr = Math.sqrt(dx * dx + dy * dy);
        return "M" +
            d.source.x + "," +
            d.source.y + "A" +
            dr + "," + dr + " 0 0,1 " +
            d.target.x + "," +
            d.target.y;
    });

    node
        .attr("transform", function(d) {
        return "translate(" + d.x + "," + d.y + ")"; })
};

function dragstarted(d) {
      if (!d3.event.active) force.alphaTarget(0.3).restart();
      d.fx = d.x;
      d.fy = d.y;
    };

function dragged(d) {
  d.fx = d3.event.x;
  d.fy = d3.event.y;
};

function dragended(d) {
  if (!d3.event.active) force.alphaTarget(0);
  if (d.fixed == true){
     d.fx = d.x;
     d.fy = d.y;
  }
  else{
    d.fx = null;
    d.fy = null;
  }

};

function pinned(d) {
	if (d.fixed) {
		d.fx = null;
    	d.fy = null;
		d3.select(this)
			.classed("fixed", d.fixed = false)
			.style("stroke", "black")
			.style("stroke-width", "1.5px");
	} else {
		d.fx = d.x;
     	d.fy = d.y;
		
		d3.select(this)
			.classed("fixed", d.fixed = true)
			.style("stroke", "orange")
			.style("stroke-width", "5px");
	}
};