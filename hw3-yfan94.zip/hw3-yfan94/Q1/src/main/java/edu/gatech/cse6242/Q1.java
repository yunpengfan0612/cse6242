package edu.gatech.cse6242;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.util.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import java.io.IOException;

public class Q1 {

	public static class GraphMapper
		extends Mapper<Object, Text, Text, Text>{

		public void map(Object key, Text value, Context context
				) throws IOException, InterruptedException {
			String line = value.toString();
			String[] edge = line.split("\t");
			if (edge.length == 3) {
				int tgt = Integer.parseInt(edge[1]);
				int weight = Integer.parseInt(edge[2]);
				context.write(new Text(edge[0]), new Text(Integer.toString(tgt) + "," + Integer.toString(weight)));
			}
		}
	}

	public static class MaxWeightReducer
  		extends Reducer<Text, Text, Text, Text> {
	    public void reduce(Text key, Iterable<Text> values, Context context
	                       ) throws IOException, InterruptedException {
	     	int max = 0;
	     	int tgt = 0;
	      	for (Text t : values) {
	      		String line = t.toString();
	      		String[] edge = line.split(",");
	      		int myTgt = Integer.parseInt(edge[0]);
	      		int myWeight = Integer.parseInt(edge[1]);
				if (myWeight > max) {
					max = myWeight;
					tgt = myTgt;
				}
				if (myWeight == max) {
					if (tgt > myTgt) {
						tgt = myTgt;
					}
				}
	      	}
	      	context.write(key, new Text(Integer.toString(tgt) + "," + Integer.toString(max)));
	    }
	}


	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Q1");

		/* TODO: Needs to be implemented */
		job.setJobName("myFirstMapReduce");
		job.setJarByClass(Q1.class);
		job.setMapperClass(GraphMapper.class);
		job.setCombinerClass(MaxWeightReducer.class);
		job.setReducerClass(MaxWeightReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
