// Databricks notebook source
// Q2 [25 pts]: Analyzing a Large Graph with Spark/Scala on Databricks

// STARTER CODE - DO NOT EDIT THIS CELL
import org.apache.spark.sql.functions.desc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import spark.implicits._

// COMMAND ----------

// STARTER CODE - DO NOT EDIT THIS CELL
// Definfing the data schema
val customSchema = StructType(Array(StructField("answerer", IntegerType, true), StructField("questioner", IntegerType, true),
    StructField("timestamp", LongType, true)))

// COMMAND ----------

// STARTER CODE - YOU CAN LOAD ANY FILE WITH A SIMILAR SYNTAX.
// MAKE SURE THAT YOU REPLACE THE examplegraph.csv WITH THE mathoverflow.csv FILE BEFORE SUBMISSION.
val df = spark.read
   .format("com.databricks.spark.csv")
   .option("header", "false") // Use first line of all files as header
   .option("nullValue", "null")
   .schema(customSchema)
   .load("/FileStore/tables/examplegraph.csv")
   .withColumn("date", from_unixtime($"timestamp"))
   .drop($"timestamp")

// COMMAND ----------

//display(df)
df.show()

// COMMAND ----------

// PART 1: Remove the pairs where the questioner and the answerer are the same person.
// ALL THE SUBSEQUENT OPERATIONS MUST BE PERFORMED ON THIS FILTERED DATA

// ENTER THE CODE BELOW
val filterDF = df.filter($"answerer" !== $"questioner")
display(filterDF)

// COMMAND ----------

// PART 2: The top-3 individuals who answered the most number of questions - sorted in descending order - if tie, the one with lower node-id gets listed first : the nodes with the highest out-degrees.

// ENTER THE CODE BELOW
val top3Answerer = filterDF.select($"answerer")
                        .groupBy($"answerer")
                        .agg(count($"answerer") as "questions_answered")
                        .orderBy($"questions_answered".desc, $"answerer")
                        .limit(3)
display(top3Answerer)

// COMMAND ----------

// PART 3: The top-3 individuals who asked the most number of questions - sorted in descending order - if tie, the one with lower node-id gets listed first : the nodes with the highest in-degree.

// ENTER THE CODE BELOW
val top3Questioner = filterDF.select($"questioner")
                        .groupBy($"questioner")
                        .agg(count($"questioner") as "questions_asked")
                        .orderBy($"questions_asked".desc, $"questioner")
                        .limit(3)
display(top3Questioner)

// COMMAND ----------

// PART 4: The top-5 most common asker-answerer pairs - sorted in descending order - if tie, the one with lower value node-id in the first column (u->v edge, u value) gets listed first.

// ENTER THE CODE BELOW
val top5Pair = filterDF.select($"answerer", $"questioner")
                        .groupBy($"answerer", $"questioner")
                        .agg(count(lit(1)) as "count")
                        .orderBy($"count".desc, $"answerer", $"questioner")
                        .limit(5)
display(top5Pair)

// COMMAND ----------

// PART 5: Number of interactions (questions asked/answered) over the months of September-2010 to December-2010 (i.e. from September 1, 2010 to December 31, 2010). List the entries by month from September to December.

// Reference: https://www.obstkel.com/blog/spark-sql-date-functions
// Read in the data and extract the month and year from the date column.
// Hint: Check how we extracted the date from the timestamp.

// ENTER THE CODE BELOW
val newDF = filterDF.withColumn("year", substring($"date", 1, 4))
                    .withColumn("month", substring($"date", 6, 2))
                    .withColumn("theDate", substring($"date", 9, 2))
                    .withColumn("myDate", concat(col("year"), lit(""), col("month"), lit(""), col("theDate")))
                    .filter($"myDate" >= 20100901 && $"myDate" <= 20101231)

val totalSept = newDF.withColumn("month", col("month").cast("Int"))
                     .select($"month")
                     .groupBy($"month")
                     .agg(count($"month") as "total_interactions")
display(totalSept)



// COMMAND ----------

// PART 6: List the top-3 individuals with the maximum overall activity, i.e. total questions asked and questions answered.

// ENTER THE CODE BELOW
val topAnswerer = filterDF.select($"answerer")
                        .groupBy($"answerer")
                        .agg(count($"answerer") as "questions_answered")
                        .orderBy($"questions_answered".desc, $"answerer")

val topQuestioner = filterDF.select($"questioner")
                        .groupBy($"questioner")
                        .agg(count($"questioner") as "questions_asked")
                        .orderBy($"questions_asked".desc, $"questioner")

val top3User = topAnswerer.join(topQuestioner, topAnswerer("answerer") === topQuestioner("questioner"))
           .withColumn("userID", $"answerer")
           .withColumn("total_activity", $"questions_answered" + $"questions_asked")
           .orderBy($"total_activity".desc)
           .drop($"answerer")
           .drop($"questioner")
           .drop($"questions_answered")
           .drop($"questions_asked")
           .limit(3)

display(top3User)
