package edu.gatech.cse6242;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.util.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import java.io.IOException;

public class Q4 {

	public static class Mapper1
		extends Mapper<Object, Text, Text, IntWritable>{

		private final static IntWritable one = new IntWritable(1);
        private final static IntWritable minusOne = new IntWritable(-1);

		public void map(Object key, Text value, Context context
				) throws IOException, InterruptedException {
			String line = value.toString();
			String[] edge = line.split("\t");
			if (edge.length == 2) {
				context.write(new Text(edge[0]), one);
				context.write(new Text(edge[1]), minusOne);
			}
		}
	}

	public static class Reducer1
  		extends Reducer<Text, IntWritable, Text, IntWritable> {
	    public void reduce(Text key, Iterable<IntWritable> values, Context context
	                       ) throws IOException, InterruptedException {
	     	int sum = 0;
	     	for (IntWritable v: values) {
	     		sum += v.get();
	     	}
	      	context.write(key, new IntWritable(sum));
	    }
	}

	public static class Mapper2
		extends Mapper<Object, Text, Text, IntWritable>{

		private final static IntWritable one = new IntWritable(1);

		public void map(Object key, Text value, Context context
				) throws IOException, InterruptedException {
			String line = value.toString();
			String[] edge = line.split("\t");
			context.write(new Text(edge[1]), one);
		}
	}

	public static class Reducer2
  		extends Reducer<Text, IntWritable, Text, IntWritable> {
	    public void reduce(Text key, Iterable<IntWritable> values, Context context
	                       ) throws IOException, InterruptedException {
	     	int sum = 0;
	     	for (IntWritable v: values) {
	     		sum += v.get();
	     	}
	      	context.write(key, new IntWritable(sum));
	    }
	}


	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Q4");

		/* TODO: Needs to be implemented */
		job.setJarByClass(Q4.class);
		job.setMapperClass(Mapper1.class);
		job.setCombinerClass(Reducer1.class);
		job.setReducerClass(Reducer1.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		Path outputPath = new Path("MapReduce1");
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, outputPath);
		job.waitForCompletion(true);

		Configuration conf2 = new Configuration();
		Job job2 = Job.getInstance(conf2, "Q4");
		job2.setJarByClass(Q4.class);
		job2.setMapperClass(Mapper2.class);
		job2.setCombinerClass(Reducer2.class);
		job2.setReducerClass(Reducer2.class);
		job2.setOutputKeyClass(Text.class);
		job2.setOutputValueClass(IntWritable.class);

		FileInputFormat.addInputPath(job2, outputPath);
		FileOutputFormat.setOutputPath(job2, new Path(args[1]));
		System.exit(job2.waitForCompletion(true) ? 0 : 1);
	}
}
